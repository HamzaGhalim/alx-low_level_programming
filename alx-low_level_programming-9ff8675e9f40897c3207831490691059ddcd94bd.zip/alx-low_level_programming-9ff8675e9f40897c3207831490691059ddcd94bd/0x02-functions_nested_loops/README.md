C - Functions, nested loops
